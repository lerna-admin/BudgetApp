export const MuiCardActions = {
	styleOverrides: { root: { padding: "8px 16px 16px" } },
};
