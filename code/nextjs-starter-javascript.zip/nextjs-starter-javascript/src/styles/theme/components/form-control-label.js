export const MuiFormControlLabel = {
	defaultProps: { slotProps: { typography: { variant: "subtitle2" } } },
	styleOverrides: { root: { gap: "8px", margin: 0 } },
};
