export const MuiListItemButton = {
	defaultProps: { disableRipple: true },
	styleOverrides: { root: { gap: "var(--ListItem-gap)" } },
};
