export const MuiListItemIcon = {
	styleOverrides: { root: { color: "inherit", fontSize: "var(--icon-fontSize-md)", minWidth: "auto" } },
};
