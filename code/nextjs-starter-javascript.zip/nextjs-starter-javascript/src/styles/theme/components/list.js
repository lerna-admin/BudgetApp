export const MuiList = {
	styleOverrides: { root: { "--ListItem-gap": "16px" } },
};
