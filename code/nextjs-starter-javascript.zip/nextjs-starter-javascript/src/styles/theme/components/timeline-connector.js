export const MuiTimelineConnector = {
	styleOverrides: { root: { backgroundColor: "var(--mui-palette-divider)" } },
};
