"use client";

export { PDFViewer } from "@react-pdf/renderer";
