export const de = {
	common: {
		languageChanged: "Sprache geändert",
	},
	translations: {
		content:
			"Diese Nachricht wird von einer React-Komponente gerendert und zeigt interaktive Elemente und dynamische Aktualisierungen ohne vollständiges Neuladen der Seite.",
	},
};
