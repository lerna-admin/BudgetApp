import * as React from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Container from "@mui/material/Container";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { Helmet } from "react-helmet-async";

import { appConfig } from "@/config/app";
import { paths } from "@/paths";
import { RouterLink } from "@/components/core/link";

const metadata = { title: `Not authorized | Errors | ${appConfig.name}` };

export function Page() {
	return (
		<React.Fragment>
			<Helmet>
				<title>{metadata.title}</title>
			</Helmet>
			<Box
				component="main"
				sx={{
					alignItems: "center",
					display: "flex",
					flexDirection: "column",
					justifyContent: "center",
					minHeight: "100%",
					py: "64px",
				}}
			>
				<Container maxWidth="lg">
					<Stack spacing={6}>
						<Box sx={{ display: "flex", justifyContent: "center" }}>
							<Box
								alt="Not authorized"
								component="img"
								src="/assets/error.svg"
								sx={{ height: "auto", maxWidth: "100%", width: "200px" }}
							/>
						</Box>
						<Stack spacing={1} sx={{ textAlign: "center" }}>
							<Typography variant="h4">401: Authorization required</Typography>
							<Typography color="text.secondary">
								You either tried some shady route or you came here by mistake. Whichever it is, try using the
								navigation.
							</Typography>
						</Stack>
						<Box sx={{ display: "flex", justifyContent: "center" }}>
							<Button component={RouterLink} href={paths.home} variant="contained">
								Back to home
							</Button>
						</Box>
					</Stack>
				</Container>
			</Box>
		</React.Fragment>
	);
}
