export const MuiListItemAvatar = {
	styleOverrides: { root: { minWidth: "auto" } },
};
