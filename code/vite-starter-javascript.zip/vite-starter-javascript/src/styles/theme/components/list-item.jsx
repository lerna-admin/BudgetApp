export const MuiListItem = {
	styleOverrides: { root: { gap: "var(--ListItem-gap)" } },
};
