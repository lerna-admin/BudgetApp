export const MuiPopover = {
	defaultProps: { disableScrollLock: true, elevation: 16 },
	styleOverrides: { paper: { border: "1px solid var(--mui-palette-divider)" } },
};
