export const en = {
	common: {
		languageChanged: "Language changed",
	},
	translations: {
		content:
			"This message is rendered by a React Component, showcasing interactive elements and dynamic updates without full page reloads.",
	},
};
